$(document).ready(function () {
  $(".hamburger").click(function () {
    $(".x-btn").show();
    $(".hamburger").hide();
    $(".menubar_list").fadeIn(500);
    $(".menubar_row").css("padding-top", "10px");
    $(".menubar_row").css("transition", "all 0.5s ease-in-out");
    $(".menubar_list").css("transition", "all 0.5s ease-in-out");
  });
  $(".x-btn").click(function () {
    $(".x-btn").hide();
    $(".hamburger").show();
    $(".menubar_list").fadeOut(500);
    $(".menubar_row").css("padding-top", "0px");
    $(".menubar_row").css("transition", "all 0.5s ease-in-out");
    $(".menubar_list").css("transition", "all 0.5s ease-in-out");

  });

});


$(document).ready(function () {
  $({ Counter: 0 }).animate({
    Counter: $('.count1').text()
  }, {
    duration: 2000,
    easing: 'swing',
    step: function () {
      $('.count1').text(Math.ceil(this.Counter));
    }
  });
});

$(document).ready(function () {
  $({ Counter: 0 }).animate({
    Counter: $('.count2').text()
  }, {
    duration: 2000,
    easing: 'swing',
    step: function () {
      $('.count2').text(Math.ceil(this.Counter));
    }
  });
});

$(document).ready(function () {
  $({ Counter: 0 }).animate({
    Counter: $('.count3').text()
  }, {
    duration: 2000,
    easing: 'swing',
    step: function () {
      $('.count3').text(Math.ceil(this.Counter));
    }
  });
});

$(document).ready(function () {
  $({ Counter: 0 }).animate({
    Counter: $('.count4').text()
  }, {
    duration: 2000,
    easing: 'swing',
    step: function () {
      $('.count4').text(Math.ceil(this.Counter));
    }
  });
});

/////

$(document).ready(function () {
  $(".column-hover1").mouseover(function () {
    $(".heading-hover1").css("color", "red");
    $(".heading-hover1").css("transition", "all 0.5s ease-in-out");
  });
  $(".column-hover1").mouseout(function () {
    $(".heading-hover1").css("color", "#121212");
    $(".heading-hover1").css("transition", "all 0.3s ease-in-out");
  });

});

$(document).ready(function () {
  $(".column-hover2").mouseover(function () {
    $(".heading-hover2").css("color", "red");
    $(".heading-hover2").css("transition", "all 0.5s ease-in-out");
  });
  $(".column-hover2").mouseout(function () {
    $(".heading-hover2").css("color", "#121212");
    $(".heading-hover2").css("transition", "all 0.3s ease-in-out");
  });

});

$(document).ready(function () {
  $(".column-hover3").mouseover(function () {
    $(".heading-hover3").css("color", "red");
    $(".heading-hover3").css("transition", "all 0.5s ease-in-out");
  });
  $(".column-hover3").mouseout(function () {
    $(".heading-hover3").css("color", "#121212");
    $(".heading-hover3").css("transition", "all 0.3s ease-in-out");
  });

});


//////////////////////////
/////////////////////////
/////////////////////////


$(document).ready(function () {
  $({ Counter: 0 }).animate({
    Counter: $('.barnumber1').text()
  }, {
    duration: 2000,
    easing: 'swing',
    step: function () {
      $('.barnumber1').text(Math.ceil(this.Counter));
    }
  });
});

$(document).ready(function () {
  $({ Counter: 0 }).animate({
    Counter: $('.barnumber2').text()
  }, {
    duration: 2000,
    easing: 'swing',
    step: function () {
      $('.barnumber2').text(Math.ceil(this.Counter));
    }
  });
});

$(document).ready(function () {
  $({ Counter: 0 }).animate({
    Counter: $('.barnumber3').text()
  }, {
    duration: 2000,
    easing: 'swing',
    step: function () {
      $('.barnumber3').text(Math.ceil(this.Counter));
    }
  });
});

$(document).ready(function () {
  $({ Counter: 0 }).animate({
    Counter: $('.barnumber4').text()
  }, {
    duration: 2000,
    easing: 'swing',
    step: function () {
      $('.barnumber4').text(Math.ceil(this.Counter));
    }
  });
});

///////////////////////////
//////parallex////////////

$(document).ready(function () {
$('.my_slider').slick({
  dots: true,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
});

});






///////////////
/////map////////////

function initMap() {

  var macc = {lat: 42.1382114, lng: -71.5212585};

  var map = new google.maps.Map(

      document.getElementById('iframe'), {zoom: 15, center: macc});

  var marker = new google.maps.Marker({position: macc, map: map});

}